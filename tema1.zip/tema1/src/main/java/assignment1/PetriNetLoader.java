package assignment1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import javax.json.Json;
import javax.json.JsonArray;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class PetriNetLoader {

    void load() throws JsonMappingException, JsonProcessingException {

        String filePath = "PetriNetInput.json";

        String jsonString = read(filePath);

        JSONParser parser = new JSONParser();
        JSONObject json1;
        
        try {
            json1 = (JSONObject) parser.parse(jsonString);
            System.out.println(json1.toString());

            ObjectualModel objectualModel = new ObjectualModel(json1);
            objectualModel.createModel();  

        } catch (ParseException e) { 
            e.printStackTrace();
        }
      
     

    }
    private static String read(String filePath) 
    {
        StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) 
        {
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null) 
            {
                contentBuilder.append(sCurrentLine);
            }
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
        }
        return contentBuilder.toString();
    }
}