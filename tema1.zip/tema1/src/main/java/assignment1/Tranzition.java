package assignment1;

import java.util.ArrayList;

public class Tranzition {
     int[] durationInterval;
     String name;
     ArrayList<Location>  inLocations;
     ArrayList<Location>  outLocations;

    public Tranzition(String name, int[] temp, ArrayList<Location>  inputs,ArrayList<Location>  outputs){
        this.name = name;
        this.durationInterval = temp;
        this.inLocations = inputs;
        this.outLocations = outputs;
    }

    public void fireTranzition(){
        for (Location i : inLocations) {
            i.extractTokens(1);
        }
        for (Location o : outLocations) {
            o.addTokens(1);
        }
    }
    public int[] getDurationInterval(){
        return this.durationInterval;
    }
}