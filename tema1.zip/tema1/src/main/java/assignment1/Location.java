package assignment1;

import java.util.ArrayList;

public class Location {
    int tokens;
    ArrayList<Tranzition>  inTranzitions;
    ArrayList<Tranzition> outTranzitions;
    String name;
    String type;

    public Location(String n){
        this.name = n;
    }
    public Location(String n, String t){
        this.name = n;
        this.type = t;

    }
    public Location(int t, ArrayList<Tranzition> inTranzitions, ArrayList<Tranzition> outTranzitions){
        this.tokens = t;
        this.inTranzitions = inTranzitions;
        this.outTranzitions = outTranzitions;
    }
    public int getTokens(){
        return this.tokens;
    }
    public void setTokens(int t){
        this.tokens = t;
    }
    public void extractTokens(int t){
        this.tokens -= t;
    }
    public void addTokens(int t){
        this.tokens += t;
    }
}