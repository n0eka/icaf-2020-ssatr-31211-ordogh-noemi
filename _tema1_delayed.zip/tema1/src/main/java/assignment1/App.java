package assignment1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public final class App {
    private App() {
    }

    public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
        PetriNetLoader loader = new PetriNetLoader();
        loader.load();
    }
}
