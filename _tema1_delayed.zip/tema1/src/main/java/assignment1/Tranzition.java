package assignment1;

import java.util.ArrayList;

public class Tranzition {
     int[] durationInterval = new int[2];
     String name;
     ArrayList<Location>  inLocations;
     ArrayList<Location>  outLocations;

    public Tranzition(String name, int[] temp, ArrayList<Location>  inputs,ArrayList<Location>  outputs){
        this.name = name;
        this.inLocations = inputs;
        this.outLocations = outputs;

        if(temp[0] > temp[1]){
            this.durationInterval[0] = temp[0];
            this.durationInterval[1] = temp[0];
        } else
        {
            this.durationInterval = temp;
        }
    }
    public boolean checkTranzitionIsexecutable(){
        for (Location l: inLocations){
            if(l.tokens == 0)
            {
                return false;
            }
        }
        return true;
    }

    public void fireTranzitionStart(){
        System.out.println("Tranzition " + this.name + " started:tokens extracted from inLocation");
        for (Location i : inLocations) {
            i.extractTokens(1);
        }
    }
    public Boolean fireTranzitionEnd(){
        if(outLocations == null) {
            return false;
        }
        else{
            for (Location o : outLocations) {
                o.addTokens(1);
            }
            System.out.println("tokens added to outLocations. End of tranzition "+ this.name);
            return true;
        }
        

    }
    public int[] getDurationInterval(){
        return this.durationInterval;
    }
    public String toStringTranzition(){
        Integer d1  = this.durationInterval[0];
        Integer d2 = this.durationInterval[1];
        String inlist = " ";
        String outlist = " ";

        for (Location i : inLocations) {
            inlist = inlist.concat(i.name).concat(", ");   
        }
        for (Location i : outLocations) {
            outlist = outlist.concat(i.name).concat(", ");  
        }
        String t = "name: " + this.name +  ",duartionInterval: From: " + d1.toString() + " To: " + d2.toString() + ", inLocations: " + inlist + ", outLocations: " + outlist;
        return t;
    }
}