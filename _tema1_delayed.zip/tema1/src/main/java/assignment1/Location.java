package assignment1;

import java.util.ArrayList;

public class Location {
    int tokens;
    ArrayList<Tranzition>  inTranzitions = new ArrayList<Tranzition>();
    ArrayList<Tranzition> outTranzitions = new ArrayList<Tranzition>();
    String name;
    String type;

    public Location(String n){
        this.name = n;
    }
    public Location(String n, String t, String tokens){
        this.name = n;
        this.type = t;
        this.tokens = Integer.parseInt(tokens);  
        

    }
    public void addInTranzition(Tranzition inTranzition){
        this.inTranzitions.add(inTranzition);
    }
    public void addOutTranzition(Tranzition outTranzition){
        this.outTranzitions.add(outTranzition);
    }
    public int getTokens(){
        return this.tokens;
    }
    public void setTokens(int t){
        this.tokens = t;
    }
    public void extractTokens(int t){
        this.tokens -= t;
    }
    public String getType(){
        return this.type;
    }
    public void addTokens(int t){
        this.tokens += t;
    }
    public String toStringLocation(){
        String inlist = " ";
        String outlist = " ";

        for (Tranzition i : inTranzitions) {
            inlist = inlist.concat(i.name).concat(", ");   
        }
        for (Tranzition i : outTranzitions) {
            outlist = outlist.concat(i.name).concat(", ");  
        }
        String t = "name: " + this.name +  ",type:  " + this.type + ", tokens: " +this.tokens + ", intranzitions: " + inlist + ", outTranzitions: " + outlist;
        return t;
    }
}