package assignment1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import javax.json.Json;
import javax.json.JsonArray;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ObjectualModel {

    JSONObject json1;
    ArrayList<Location> locations;
    ArrayList<Tranzition> tranzitions;

    ObjectualModel(JSONObject json1){
        this.json1 = json1;
        locations = new ArrayList<>();
        tranzitions = new ArrayList<>();
    }
    public String removeFirstandLast(String str) 
    { 
        // Creating a StringBuilder object 
        StringBuilder sb = new StringBuilder(str); 
  
        // Removing the last character  
        sb.deleteCharAt(str.length() - 1); 
  
        // Removing the first character 
        sb.deleteCharAt(0); 

        return sb.toString(); 
    } 

    void createModel() throws JsonMappingException, JsonProcessingException{
        
        JSONArray arr = (JSONArray) json1.get("locations");
            
        for(int i=0; i<arr.size();i++){
            JSONObject jo = (JSONObject) arr.get(i);
            Object [] hm = jo.entrySet().toArray();

            Location l = new Location(((Map.Entry)hm[0]).getValue().toString(), ((Map.Entry)hm[2]).getValue().toString(),((Map.Entry)hm[1]).getValue().toString());
            locations.add(l);
            //System.out.println(l.toStringLocation());
        }
        JSONArray arr2 = (JSONArray) json1.get("transitions");
            
        for(int i=0; i<arr2.size();i++){
            JSONObject jo = (JSONObject) arr2.get(i);
            Object [] hm = jo.entrySet().toArray();
            int[] durationInterval = new int[2];
            ArrayList<Location> inLocation = new ArrayList<>();
            ArrayList<Location> outLocation = new ArrayList<>();
            String name = null;
            for(int sProp =0; sProp<hm.length;sProp++){
                String sKey = ((Map.Entry)hm[sProp]).getKey().toString();
                switch(sKey) {
                  case "name": {
                        // name
                        name = ((Map.Entry)hm[sProp]).getValue().toString();
                    break;
                  } 
                  case "duration": {
                        // duration
                        JSONArray arrValues = (JSONArray) ((Map.Entry)hm[sProp]).getValue();
                        for(int k=0; k<arrValues.size();k++){
                            String durationValue = (String) arrValues.get(k);
                            int d = Integer.parseInt(durationValue); 
                            durationInterval[k] = d;
                        }
                      break;
                  } 
                  case "inputs": {
                        // inLocation
                        
                        JSONArray arrValues = (JSONArray) ((Map.Entry)hm[sProp]).getValue();
                        for(int k=0; k<arrValues.size();k++){
                            String in = (String) arrValues.get(k);
                            inLocation.add(findLocation(in));
                        }
                        break;
                  }
                  case "outputs": {
                        // outLocation
                       
                        JSONArray arrValues = (JSONArray) ((Map.Entry)hm[sProp]).getValue();
                        for(int k=0; k<arrValues.size();k++){
                            String out = (String) arrValues.get(k);
                            if (out.equals("0")){
                              //  outLocation = null;
                                
                            } else{
                                outLocation.add(findLocation(out));
                            }
                           
                        }
                        break;
                  }
                  default: {
                      break;
                  }
               }
            }

             Tranzition t = new Tranzition(name, durationInterval, inLocation,outLocation);
             tranzitions.add(t);
             System.out.println(t.toStringTranzition());
        }
        
        createPetrinet();
        SimulationEngine simulatePetriNet = new SimulationEngine(locations, tranzitions);
        simulatePetriNet.simulate();
    }
    public void createPetrinet(){
        for (Tranzition tranzition : tranzitions) {
            ArrayList<Location> inLocations = tranzition.inLocations;
            ArrayList<Location> outLocations = tranzition.outLocations;
            for (Location l : inLocations) {  
                if ((l.outTranzitions == null) || !l.outTranzitions.contains(tranzition)){
                    l.addOutTranzition(tranzition);
                }          
            }
            if(tranzition.outLocations.equals(null)){

            }
            else{
                for (Location l : outLocations) {  
                    if(!(l.inTranzitions.contains(tranzition))){
                        l.addInTranzition(tranzition);
                    }          
                }
            }
            
        }
        for (Location l : locations) {
            System.out.println(l.toStringLocation()); 

        }
    }
    public Location findLocation (String n){
        for (Location l : locations) {
            if (l.name.equals(n)){
                return l;
            }
        }
        return null;
    }
}
