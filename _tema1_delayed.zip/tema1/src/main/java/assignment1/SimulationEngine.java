package assignment1;

import java.util.ArrayList;

public class SimulationEngine {
    ArrayList<Location> locations;
    ArrayList<Tranzition> tranzitions;
    private int time;
    private Boolean active = false;
    int counter = -1;
    
    public SimulationEngine(ArrayList<Location> locations, ArrayList<Tranzition> tranzitions){
        this.locations = locations;
        this.tranzitions = tranzitions;
    }

    public void simulate(){
        System.out.println("simulation started.");
        Location start = getFirstLocation();
        Location currentLocation = start;
        ArrayList<Location> nextLocations = new ArrayList<>();
        ArrayList<Tranzition> executableTr = new ArrayList<>();
        for (Tranzition tranzition : start.outTranzitions) {
            executableTr.add(tranzition);
        }
        
        while(this.active){
            System.out.println("current time is: "+time);
            for (Location location : nextLocations) {
                for (Tranzition trAdd : location.outTranzitions) {
                    executableTr.add(trAdd);
                }
            }
            nextLocations.clear();
            for (Tranzition t : executableTr) {
                if (t.checkTranzitionIsexecutable() == true){
                    t.fireTranzitionStart();
                    tranzitionDelay(t.durationInterval);
                    if(t.fireTranzitionEnd()){
                        for (Location nextLoc : t.outLocations) {
                            nextLocations.add(nextLoc);
                        }
                    }
                    else{
                        this.active = false;
                    }
                }
                
            }
            executableTr.clear();

        }
    }
    public Location getFirstLocation(){
        for (Location location : locations) {
            if (location.type.equals("start")){
               return location;
            }
        }
        return new Location("name"); 
    }
    public Tranzition getTranzitionsFromlocation(Location l){
        for (Tranzition tranzition :  tranzitions) {
            if (tranzition.inLocations.equals(l)){
               //return tranzition.outLocations;
            }
        }
        return null; 
    }
    public void tranzitionDelay(int[] durationInterval){
        int start = durationInterval[0];
        int end = durationInterval[1];
        System.out.println("transition entered in waiting phase");
        int duration;

        if (start == end){
            duration = start;
        }
        else{
            duration =  (int) ((Math.random() * (end - start)) + start);
            counter = duration;

        }
        if(duration>0 ){
            duration --;
            counter = duration;

        }else {
            counter = -1;
        }

    }
}
